import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import logo from "./assets/logo.svg"; // Add your logo to src/assets/logo.svg

export default function FootyesHome() {
  return (
    <div className="min-h-screen bg-black text-gray-200 font-sans">
      <header className="p-6 shadow-md bg-black border-b border-gray-700 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <img src={logo} alt="Footyes Logo" className="h-10 w-10" />
          <h1 className="text-4xl font-bold text-silver">Footyes</h1>
        </div>
        <nav className="flex space-x-6 text-gray-400">
          <a href="#" className="hover:text-white">Home</a>
          <a href="#" className="hover:text-white">News</a>
          <a href="#" className="hover:text-white">Shop</a>
          <a href="#" className="hover:text-white">Community</a>
          <a href="#" className="hover:text-white">Contact</a>
        </nav>
      </header>

      <main className="p-8 grid gap-6">
        <section className="text-center">
          <h2 className="text-3xl font-semibold text-silver">Welcome to Footyes</h2>
          <p className="mt-2 text-gray-400">Your ultimate football destination — news, gear, and fan talk</p>
          <Button className="mt-6 border border-silver text-silver hover:bg-silver hover:text-black">Join Now</Button>
        </section>

        <section>
          <h3 className="text-2xl font-semibold mb-4 text-silver">Latest News</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map((_, i) => (
              <Card key={i} className="bg-gray-900 border border-gray-700">
                <CardContent className="p-4">
                  <h4 className="text-xl font-bold text-silver">Match Headline #{i + 1}</h4>
                  <p className="mt-2 text-gray-400">Brief summary of the match or news article goes here.</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-semibold mb-4 text-silver">Shop Jerseys</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((_, i) => (
              <Card key={i} className="bg-gray-900 border border-gray-700">
                <CardContent className="p-4 flex flex-col items-center">
                  <div className="w-full h-32 bg-gray-800 mb-2"></div>
                  <p className="text-gray-300">Team Jersey #{i + 1}</p>
                  <Button className="mt-2 border border-silver text-silver hover:bg-silver hover:text-black w-full">Buy</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-semibold mb-4 text-silver">Fan Community</h3>
          <div className="space-y-4">
            {[
              "Who will win the UCL?",
              "Favorite player of the season?",
              "Best football boots in 2025?"
            ].map((topic, i) => (
              <Card key={i} className="bg-gray-900 border border-gray-700">
                <CardContent className="p-4">
                  <h4 className="text-lg font-bold text-silver">{topic}</h4>
                  <p className="mt-2 text-gray-400">Join the discussion in the forums and share your thoughts.</p>
                  <Button className="mt-2 border border-silver text-silver hover:bg-silver hover:text-black">Reply</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="p-6 border-t border-gray-700 text-center text-gray-500">
        © 2025 footyes.com — All rights reserved
      </footer>
    </div>
  );
}
