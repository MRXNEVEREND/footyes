import React from "react";
import FootyesHome from "./FootyesHome";

function App() {
  return <FootyesHome />;
}

export default App;
